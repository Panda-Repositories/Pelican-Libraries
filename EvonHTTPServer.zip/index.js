const express = require('express');
const fs = require('fs');

const app = express();
const PORT = 2023;

app.get('/:command', (req, res) => {
  const command = req.params.command;

  if (command === 'readcontent') {
    // Read the content from content.txt
    fs.readFile('content.txt', 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Internal Server Error');
      }

      // Check if the content has been read before
      if (data.trim() === 'Ready') {
        // If already read, send a message
        res.send('No_Data_Set_Here');
      } else {
        // Send the content as plain text
        res.send(`${data}`);
      }
    });
  } else if (command === 'clear') {
    // Clear the content by setting it to "Ready"
    fs.writeFile('content.txt', 'Ready', (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Internal Server Error');
      }
      res.send('Done');
    });
  } else {
    res.status(400).send('Invalid Command');
  }
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
